import {Component} from'@angular/core';

@Component({
    selector:'parent',
    template:`
            <my-app></my-app>
            <br/>
            <two></two>`    
})
export class ParentComponent{



}