import { NgModule } from "@angular/core";
import { BrowserModule } from '@angular/platform-browser';
import {ParentComponent} from './parent';
import { FormsModule } from '@angular/forms';
import { LoginCompoent } from "./Login";
import { MainPage } from "./page";
import { ReactiveFormsModule} from '@angular/forms';

@NgModule({
    declarations: [
        ParentComponent,LoginComponent,MainPage
      ],
      imports: [
        BrowserModule,FormsModule,ReactiveFormsModule
      ],
      bootstrap: [ParentComponent]
    })
export class ParentModule{

}