import { Component, OnInit, Input , Output,EventEmitter} from "@angular/core";
import { FormGroup,FormControl,FormBuilder, Validators } from "@angular/forms";
import { debounceTime } from "rxjs/operators";

@Component({
    selector:'reg',
    templateUrl:'Login.html'

})

export class LoginCompoent{
  @Input() Selected=null;
  searchField: FormControl;
  searches:string[]=[];
  userForm = new FormGroup({
    fname: new FormControl('Name', [Validators.minLength(4), Validators.maxLength(8),Validators.required]),
    lname: new FormControl('LastName', [Validators.minLength(4), Validators.maxLength(8),Validators.required]),
    email: new FormControl('my@getMaxListeners.com'),
    password: new FormControl('enter password'),
    otp: new FormControl('enter otp')
  });
  
}
  