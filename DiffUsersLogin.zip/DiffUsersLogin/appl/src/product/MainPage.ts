import { Component } from "@angular/core";

@Component({
    selector:'page',
    templateUrl:'Button.html'

})

export class MainPage{

  hide:boolean=true;
  isHower:boolean=false;
  mouseHower(event){
      this.isHower=true;
  }
  Display(){
    this.hide=false;
  }

  selectedLink: string=null;
  setradio(e: string): void   
    {  
          this.selectedLink = e;  
            
    }  
    
      isSelected(name: string): boolean   
    {  
    
          if (!this.selectedLink) { 
              return false;  
    }  
    
          return (this.selectedLink === name); 
      }  
  }
  