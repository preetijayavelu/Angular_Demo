import {Component} from'@angular/core';

@Component({
    selector:'parent',
    template:`<page></page>`    
})
export class ParentComponent{



}