import { Component } from'@angular/core';

@Component({
    selector:'parent',
    templateUrl:'parent.html'
})

export class ParentComponent {

}
