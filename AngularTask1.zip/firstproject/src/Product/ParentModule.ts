import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import {ParentComponent} from './parent';
import { ChildComponent } from '../Child/Child';

@NgModule({
  declarations: [
    ParentComponent, ChildComponent
  ],
  imports: [
    BrowserModule
  ],
  exports: [
    ParentComponent, ChildComponent
  ],
  bootstrap: [ParentComponent, ChildComponent]
})

export class ParentModule {

}
