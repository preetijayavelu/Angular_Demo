import { Component } from "@angular/core";

@Component({
  selector: 'child',
  templateUrl: 'child.html'
})


export class ChildComponent {
  data: String;
  temp;
  
  getValue(event) {
    this.temp = event;
  }

  SetInputValue() {
    this.data = this.temp.target.value;

  }
}
